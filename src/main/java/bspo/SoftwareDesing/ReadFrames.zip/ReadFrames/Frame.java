package bspo.SoftwareDesing.ReadFrames;

public class Frame {
    int x, y, side;

    public Frame(int x, int y, int side) {
        this.x = x;
        this.y = y;
        this.side = side;
    }
}
