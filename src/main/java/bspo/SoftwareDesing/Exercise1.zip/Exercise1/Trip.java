package bspo.SoftwareDessing.Exercise1;

public class Trip {
    String location;
    int packWeight;
    public Trip(String location, int packWeight){
        this.location = location;
        this.packWeight = packWeight;
    }

}
