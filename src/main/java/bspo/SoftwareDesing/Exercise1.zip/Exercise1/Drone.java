package bspo.SoftwareDessing.Exercise1;

import java.util.ArrayList;

public class Drone {
    String name;
    int maxWeight;
    ArrayList  trips;

    public Drone(String name, int maxWeight){
        this.name = name;
        this.maxWeight = maxWeight;
    }

}
