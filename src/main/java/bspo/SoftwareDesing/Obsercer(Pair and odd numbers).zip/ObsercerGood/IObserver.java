package bspo.SoftwareDesing.Observer.ObsercerGood;

public interface IObserver {
    void update();
}
