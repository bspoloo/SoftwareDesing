package bspo.SoftwareDesing.Observer.ObsercerGood;

public interface ICondition {

    public
    boolean evaluate(int x);
}
