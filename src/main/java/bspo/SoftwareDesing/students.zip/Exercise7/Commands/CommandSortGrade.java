package bspo.SoftwareDesing.Exercise7.Commands;

import bspo.SoftwareDesing.Exercise7.ISorter;

public class CommandSortGrade implements ICommand{
    @Override
    public void execute(ISorter sorter) {

    }
}
