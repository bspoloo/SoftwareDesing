package bspo.SoftwareDesing.Exercise7;

import bspo.SoftwareDesing.Exercise7.Student;

import java.util.ArrayList;

public interface ISorter {
    void sorter(ArrayList<Student> students);
}
