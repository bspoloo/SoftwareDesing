package bspo.SoftwareDesing.Exercise7;

import java.util.ArrayList;

public class SorterMix implements ISorter {
    @Override
    public void sorter(ArrayList<Student> students) {

    }
}
